<p align="center">
  <a href="https://xingye.me/game/eatkano"><img src="https://github.com/arcxingye/EatKano/blob/main/static/image/ClickBefore.png?raw=true" width="100" height="100" alt="EatKano"></a>
</p>
<div align="center">

# EatKano

_🦌 网页小游戏 🥛_

</div>


## 简介

小游戏：吃掉小鹿乃

浏览量超10,000,000+

线上版本:https://xingye.me/game/eatkano/index.php

Github Page:https://arcxingye.github.io/EatKano/index.html

## 可选功能

简易排行榜(日/周/月)

需导入并配置数据库，信息填进conn.php

如启用务必更换密钥及添加一些安全防范代码

以及对index.js进行混淆加密压缩

不需要排行榜把PHP文件都扔掉即可

## 其它事项

点下star吧~

欢迎修改和续写，需保留跳转此仓库的开源按钮

如整成自己想要的吃掉xxx，可以Fork一份改下图和字，并在github pages运行
